AutoPFP one-click gallery source repair

1. Extract this ZIP into the ROOT of your Autopfp-valenced repository (merge the .github folder).
2. Commit/push the extracted workflow file.
3. GitHub Actions > AutoPFP One-Click Setup (Gallery & Preview) > Run workflow.

The workflow rewrites the gallery module cleanly, removes duplicate collection methods/types,
adds persistent collections and file import helpers, and fixes square crop/fit processing. It
updates the README and commits the changes automatically.

This workflow does source checks only, not a full Android/Valenced build. File picker support
and cross-origin image downloads still depend on the target runtime. Avatar changes are not included.
