# AutoPFP Rotator (Valenced)

Rotates your Discord profile picture through named image collections.

- Create separate collections (for example, Chrollo, Killua, or Gojo).
- Import up to 500 images at once using Android's system multi-image document picker.
- Selected images are copied into plugin-private storage so the collection survives app restarts and temporary picker permissions.
- Also supports Wikimedia Commons search and HTTPS image links.
- Rotates sequentially or randomly, with no immediate repeat in random mode.
- Rotation interval minimum is 1 minute; Discord may enforce its own cooldowns and the plugin respects those responses.
- Images are cropped or fitted to a square and compressed on the phone before being sent through Discord's request module.

The plugin only rotates while Discord is open. Imported files are stored locally on the device.
