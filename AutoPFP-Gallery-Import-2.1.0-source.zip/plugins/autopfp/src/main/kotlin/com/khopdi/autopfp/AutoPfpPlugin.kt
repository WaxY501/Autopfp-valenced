@file:JvmName("AutoPfpPlugin")

package com.khopdi.autopfp

import android.app.Activity
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import app.valenced.plugins.PluginBuilder
import app.valenced.plugins.plugin
import app.valenced.xposed.api.registerNativeAsyncMethod
import app.valenced.xposed.api.registerNativeMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.coroutines.resume

private const val MAX_IMPORT_COUNT = 500
private const val MAX_IMAGE_BYTES = 20 * 1024 * 1024
private const val MAX_TOTAL_IMPORT_BYTES = 500 * 1024 * 1024

@Suppress("UNUSED")
val autoPfpPlugin: PluginBuilder = plugin {
    start {
        val pluginFilesDir = storageDir

        // args: [imageUrlOrFileUri, size, "cover" | "contain", jpegQuality]
        registerNativeAsyncMethod("${manifest.id}.process") { args ->
            val source = args[0] as String
            val size = (args[1] as Number).toInt()
            val fit = args[2] as String
            val quality = (args[3] as Number).toInt()
            withContext(Dispatchers.Default) { ImageProcessor.process(source, size, fit, quality) }
        }

        // Opens Android's document/photo picker and copies selected images into plugin-private storage.
        // Copying means imports survive picker URI permission expiry and app restarts.
        registerNativeAsyncMethod("${manifest.id}.pickImages") { args ->
            val requested = ((args.firstOrNull() as? Number)?.toInt() ?: MAX_IMPORT_COUNT)
                .coerceIn(1, MAX_IMPORT_COUNT)

            suspendCancellableCoroutine { continuation ->
                withAppActivity { activity: Activity ->
                    if (!continuation.isActive) return@withAppActivity
                    val componentActivity = activity as? ComponentActivity
                    if (componentActivity == null) {
                        continuation.resume(errorJson("This Discord activity does not support the Android document picker."))
                        return@withAppActivity
                    }

                    var launcher: ActivityResultLauncher<Array<String>>? = null
                    try {
                        val key = "autopfp-images-${UUID.randomUUID()}"
                        launcher = componentActivity.activityResultRegistry.register(
                            key,
                            ActivityResultContracts.OpenMultipleDocuments()
                        ) { selected: List<Uri> ->
                            val chosen = selected.take(requested)
                            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                                val response = try {
                                    importImages(activity, chosen, pluginFilesDir)
                                } catch (t: Throwable) {
                                    errorJson("${t.javaClass.simpleName}: ${t.message}")
                                }
                                withContext(Dispatchers.Main) {
                                    try { launcher?.unregister() } catch (_: Throwable) {}
                                    if (continuation.isActive) continuation.resume(response)
                                }
                            }
                        }
                        val activeLauncher = launcher
                        continuation.invokeOnCancellation {
                            activity.runOnUiThread {
                                try { activeLauncher?.unregister() } catch (_: Throwable) {}
                            }
                        }
                        (launcher ?: error("Image picker did not initialize")).launch(arrayOf("image/*"))
                    } catch (t: Throwable) {
                        try { launcher?.unregister() } catch (_: Throwable) {}
                        if (continuation.isActive) {
                            continuation.resume(errorJson("Could not open image picker: ${t.message}"))
                        }
                    }
                }
            }
        }

        registerNativeMethod("${manifest.id}.ping") { _ -> "ready (gallery import enabled)" }
    }
}

private fun errorJson(message: String): String =
    JSONObject().put("ok", false).put("error", message).toString()

private fun importImages(activity: Activity, uris: List<Uri>, pluginFilesDir: File): String {
    val folder = File(pluginFilesDir, "images").apply { mkdirs() }
    val output = JSONArray()
    var imported = 0
    var skipped = 0
    var totalImportedBytes = 0L

    for (uri in uris) {
        if (imported >= MAX_IMPORT_COUNT) break
        var destination: File? = null
        try {
            val mime = activity.contentResolver.getType(uri).orEmpty()
            if (!mime.startsWith("image/")) {
                skipped++
                continue
            }
            val extension = when (mime.lowercase()) {
                "image/jpeg", "image/jpg" -> ".jpg"
                "image/png" -> ".png"
                "image/webp" -> ".webp"
                "image/gif" -> ".gif"
                "image/bmp" -> ".bmp"
                else -> ".img"
            }
            destination = File(folder, "${UUID.randomUUID()}$extension")
            val input = activity.contentResolver.openInputStream(uri) ?: error("Cannot read selected image")
            var fileBytes = 0L
            input.use { source ->
                destination.outputStream().use { sink ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        fileBytes += count
                        if (fileBytes > MAX_IMAGE_BYTES) error("Image exceeds 20 MB")
                        if (totalImportedBytes + fileBytes > MAX_TOTAL_IMPORT_BYTES) error("Import batch exceeds 500 MB")
                        sink.write(buffer, 0, count)
                    }
                }
            }
            // Verify that Android can decode the imported file before keeping it.
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(destination.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Selected file is not a readable image")

            val title = queryDisplayName(activity, uri) ?: "Anime PFP ${imported + 1}"
            output.put(
                JSONObject()
                    .put("id", UUID.randomUUID().toString())
                    .put("url", Uri.fromFile(destination).toString())
                    .put("title", title)
                    .put("addedAt", System.currentTimeMillis())
            )
            totalImportedBytes += fileBytes
            imported++
        } catch (_: Throwable) {
            destination?.delete()
            skipped++
        }
    }

    return JSONObject()
        .put("ok", true)
        .put("images", output)
        .put("imported", imported)
        .put("skipped", skipped)
        .toString()
}

private fun queryDisplayName(activity: Activity, uri: Uri): String? {
    return try {
        activity.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0)?.substringBeforeLast('.') else null
            }
    } catch (_: Throwable) { null }
}
