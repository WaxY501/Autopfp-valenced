export interface PfpImage {
	id: string
	/** file:// path inside the plugin's private storage (or an https link from an older version). */
	url: string
	title: string
	addedAt: number
}

export type OrderMode = 'sequential' | 'random'
export type FitMode = 'cover' | 'contain'

/** A named folder of images. Each folder has its own rotation order. */
export interface Collection {
	id: string
	name: string
	order: OrderMode
	images: PfpImage[]
}

export interface RotationState {
	/** Index of the image to use next (sequential mode). */
	cursor: number
	lastChangeAt: number
	lastUrl?: string
	/** Earliest time another change may be tried (set after a Discord rate limit or an error). */
	nextAllowedAt?: number
}

export interface Settings {
	collections: Collection[]
	/** The folder the rotation uses. */
	activeId: string
	rotating: boolean
	intervalMin: number
	fit: FitMode
	size: number
	quality: number
	state: RotationState
}

export const MIN_INTERVAL_MIN = 1
export const DEFAULT_INTERVAL_MIN = 30

export const DEFAULT_SETTINGS: Settings = {
	collections: [{ id: 'default', name: 'My images', order: 'sequential', images: [] }],
	activeId: 'default',
	rotating: false,
	intervalMin: DEFAULT_INTERVAL_MIN,
	fit: 'cover',
	size: 512,
	quality: 90,
	state: { cursor: 0, lastChangeAt: 0 },
}

/** One imported file, as reported by the native importer. */
export interface ImportEntry {
	id?: string
	url: string
	title: string
	/** Sub-folder inside the zip/folder the file came from ('' = top level). */
	folder?: string
	/** Name of the zip file / picked folder the file came from ('' for loose images). */
	group?: string
}
