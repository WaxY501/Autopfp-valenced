import { callNativeMethod } from '@valenced/modules/native'
import type { ImportEntry } from './types.js'

export const PLUGIN_ID = 'com.khopdi.autopfp'

declare module '@valenced/modules/native' {
	export interface NativeMethods {
		'com.khopdi.autopfp.process': [args: [url: string, size: number, fit: string, quality: number], returnValue: string]
		'com.khopdi.autopfp.ping': [args: [], returnValue: string]
		'com.khopdi.autopfp.pick': [args: [kind: string, max: number], returnValue: string]
		'com.khopdi.autopfp.deleteFiles': [args: [json: string], returnValue: string]
	}
}

export type ProcessResult = { ok: true; data: string; width: number; height: number } | { ok: false; error: string }

/** Reads the image (private file or https link) and returns a square JPEG as base64, processed on the phone. */
export async function processImage(url: string, size: number, fit: string, quality: number): Promise<ProcessResult> {
	try {
		return JSON.parse(String(await callNativeMethod(`${PLUGIN_ID}.process`, [url, size, fit, quality]))) as ProcessResult
	} catch (e: any) {
		return { ok: false, error: String(e?.message ?? e) }
	}
}

export async function pingNative(): Promise<string> {
	try {
		return String(await callNativeMethod(`${PLUGIN_ID}.ping`, []))
	} catch (e: any) {
		return `unavailable: ${String(e?.message ?? e).slice(0, 120)}`
	}
}

export type PickKind = 'images' | 'zip' | 'folder'

export interface PickResult {
	ok: boolean
	error?: string
	entries?: ImportEntry[]
	imported?: number
	skipped?: number
}

/** Opens Android's picker (images, zip files or a whole folder) and copies everything into plugin-private storage. */
export async function pickFiles(kind: PickKind, max: number): Promise<PickResult> {
	try {
		return JSON.parse(String(await callNativeMethod(`${PLUGIN_ID}.pick`, [kind, max]))) as PickResult
	} catch (e: any) {
		return { ok: false, error: String(e?.message ?? e) }
	}
}

/** Deletes imported files from private storage (only files the plugin itself created). */
export async function deleteFiles(urls: string[]): Promise<void> {
	const local = urls.filter(u => u.startsWith('file://'))
	if (local.length === 0) return
	try {
		await callNativeMethod(`${PLUGIN_ID}.deleteFiles`, [JSON.stringify(local)])
	} catch {}
}
