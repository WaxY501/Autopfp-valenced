import React, { useEffect, useState } from 'react'
import { Image, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native'
import { activeCollection, applyImport, clampInterval, newId, normalize, removeImageFrom, renameCollection } from './core.js'
import { deleteFiles, pickFiles, type PickKind } from './bridge.js'
import { diag } from './diag.js'
import { changeNow, nextChangeText } from './rotation.js'
import { DEFAULT_SETTINGS, MIN_INTERVAL_MIN, type FitMode, type OrderMode, type PfpImage, type Settings } from './types.js'

const PAGE = 60

const s: any = {
	root: { padding: 16, gap: 12 },
	title: { fontSize: 18, fontWeight: '700', marginTop: 10 },
	hint: { opacity: 0.7 },
	row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
	wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
	field: { borderWidth: 1, borderColor: '#77777755', borderRadius: 8, padding: 10, flexGrow: 1, flexShrink: 1, minWidth: 120 },
	chip: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1, borderColor: '#77777755' },
	chipOn: { backgroundColor: '#5865f2', borderColor: '#5865f2' },
	btn: { backgroundColor: '#5865f2', paddingVertical: 9, paddingHorizontal: 12, borderRadius: 8 },
	btnMuted: { backgroundColor: '#6d6f78' },
	btnText: { color: 'white', fontWeight: '600' },
	card: { width: 128, gap: 6 },
	thumb: { width: 128, height: 128, borderRadius: 10, backgroundColor: '#77777733' },
	step: { backgroundColor: '#5865f2', width: 36, height: 36, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
}

function Btn({ label, onPress, muted }: { label: string; onPress: () => void; muted?: boolean }) {
	return (
		<Pressable style={[s.btn, muted && s.btnMuted]} onPress={onPress}>
			<Text style={s.btnText}>{label}</Text>
		</Pressable>
	)
}

function Chip({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) {
	return (
		<Pressable style={[s.chip, on && s.chipOn]} onPress={onPress}>
			<Text style={on ? { color: 'white', fontWeight: '600' } : undefined}>{label}</Text>
		</Pressable>
	)
}

export function SettingsScreen({ api }: { api: any }) {
	const storage = api.jsonStorage
	const data: Settings = normalize(storage.use())
	const col = activeCollection(data)

	/** Always reads the newest stored value, so a background change is never overwritten with an old copy. */
	const commit = (patch: Partial<Settings>) => {
		void storage.set({ ...normalize(storage.cache), ...patch }, true)
	}

	const [, setTick] = useState(0)
	useEffect(() => {
		const t = setInterval(() => setTick(n => n + 1), 1000)
		return () => clearInterval(t)
	}, [])

	const [name, setName] = useState('')
	const [msg, setMsg] = useState('')
	const [busy, setBusy] = useState(false)
	const [importing, setImporting] = useState(false)
	const [confirmDelete, setConfirmDelete] = useState(false)
	const [shown, setShown] = useState(PAGE)

	function updateActive(next: typeof col) {
		commit({ collections: data.collections.map(c => (c.id === next.id ? next : c)) })
	}

	function selectFolder(id: string) {
		setConfirmDelete(false)
		setShown(PAGE)
		commit({ activeId: id, state: { ...data.state, cursor: 0 } })
	}

	async function runImport(kind: PickKind) {
		setImporting(true)
		setMsg(kind === 'zip' ? 'Choose one or more .zip files…' : kind === 'folder' ? 'Choose a folder…' : 'Choose images…')
		try {
			const result = await pickFiles(kind, kind === 'images' ? 500 : 2000)
			if (!result.ok) return setMsg(result.error ?? 'Import failed.')
			const entries = result.entries ?? []
			if (entries.length === 0) return setMsg(result.skipped ? `Nothing imported. ${result.skipped} files were not usable images.` : 'Nothing was selected.')
			const out = applyImport(normalize(storage.cache), entries, name)
			commit({ collections: out.collections, activeId: out.activeId })
			setName('')
			setShown(PAGE)
			const where = out.counts.map(c => `${c.name} (${c.count})`).join(', ')
			setMsg(`Imported ${entries.length} images into: ${where}.${result.skipped ? ` Skipped ${result.skipped} unusable files.` : ''}`)
		} catch (e: any) {
			setMsg(String(e?.message ?? e))
		} finally {
			setImporting(false)
		}
	}

	function createFolder() {
		const clean = name.trim()
		if (!clean) return setMsg('Type a name first.')
		if (data.collections.some(c => c.name.trim().toLowerCase() === clean.toLowerCase())) return setMsg('A folder with that name already exists.')
		const id = newId()
		commit({ collections: [...data.collections, { id, name: clean, order: 'sequential', images: [] }], activeId: id, state: { ...data.state, cursor: 0 } })
		setName('')
		setMsg(`Created "${clean}".`)
	}

	function rename() {
		const next = renameCollection(data, col.id, name)
		if (!next) return setMsg('Type a new, unused name first.')
		commit({ collections: next })
		setMsg(`Renamed to "${name.trim()}".`)
		setName('')
	}

	function deleteFolder() {
		if (data.collections.length < 2) return setMsg('You need at least one folder.')
		if (!confirmDelete) {
			setConfirmDelete(true)
			return setMsg(`Tap Delete again to remove "${col.name}" and its ${col.images.length} images.`)
		}
		const rest = data.collections.filter(c => c.id !== col.id)
		void deleteFiles(col.images.map(i => i.url))
		commit({ collections: rest, activeId: rest[0].id, state: { ...data.state, cursor: 0 } })
		setConfirmDelete(false)
		setMsg('Folder deleted.')
	}

	function removeImage(img: PfpImage) {
		void deleteFiles([img.url])
		updateActive(removeImageFrom(col, img.id))
	}

	async function useNow(image?: PfpImage) {
		setBusy(true)
		setMsg(await changeNow(image))
		setBusy(false)
	}

	const visible = col.images.slice(0, shown)

	return (
		<ScrollView>
			<View style={s.root}>
				<Text style={s.title}>AutoPFP Rotator</Text>
				<Text style={s.hint}>
					{[
						`Image engine: ${diag.native}`,
						`Discord requests: ${diag.rest}`,
						nextChangeText(data),
						`Last: ${diag.lastResult}`,
					].join('\n')}
				</Text>

				<View style={s.row}>
					<Text style={{ flex: 1 }}>Rotate my profile picture automatically</Text>
					<Switch value={data.rotating} onValueChange={v => commit({ rotating: v })} />
				</View>
				<View style={s.row}>
					<Text style={{ flex: 1 }}>Change every</Text>
					<View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
						<Pressable style={s.step} onPress={() => commit({ intervalMin: clampInterval(data.intervalMin - 1) })}><Text style={s.btnText}>{'\u2212'}</Text></Pressable>
						<Text style={{ minWidth: 70, textAlign: 'center', fontWeight: '700' }}>{data.intervalMin} min</Text>
						<Pressable style={s.step} onPress={() => commit({ intervalMin: clampInterval(data.intervalMin + 1) })}><Text style={s.btnText}>+</Text></Pressable>
					</View>
				</View>
				<Text style={s.hint}>
					Minimum {MIN_INTERVAL_MIN} minute. Discord may enforce its own avatar-change cooldowns. Rotation only runs while Discord is open.
				</Text>
				<View style={s.wrap}>
					<Chip label="Fill (crop)" on={data.fit === 'cover'} onPress={() => commit({ fit: 'cover' as FitMode })} />
					<Chip label="Fit (bars)" on={data.fit === 'contain'} onPress={() => commit({ fit: 'contain' as FitMode })} />
					<Btn label={busy ? 'Working\u2026' : 'Change now'} onPress={() => void useNow()} />
				</View>
				{!!msg && <Text style={s.hint}>{msg}</Text>}

				<Text style={s.title}>Folders</Text>
				<Text style={s.hint}>Rotation only uses the selected folder.</Text>
				<View style={s.wrap}>
					{data.collections.map(c => (
						<Chip key={c.id} label={`${c.name} (${c.images.length})`} on={c.id === col.id} onPress={() => selectFolder(c.id)} />
					))}
				</View>

				<Text style={s.title}>Selected: "{col.name}"</Text>
				<Text style={s.hint}>Order for this folder:</Text>
				<View style={s.wrap}>
					<Chip label="In sequence" on={col.order === 'sequential'} onPress={() => updateActive({ ...col, order: 'sequential' as OrderMode })} />
					<Chip label="Random" on={col.order === 'random'} onPress={() => updateActive({ ...col, order: 'random' as OrderMode })} />
				</View>

				<Text style={s.hint}>Folder name (used for Create, Rename, and to name what you import next):</Text>
				<View style={s.wrap}>
					<TextInput style={s.field} value={name} onChangeText={setName} placeholder="e.g. Chrollo" autoCapitalize="none" />
				</View>
				<View style={s.wrap}>
					<Btn label="Create folder" onPress={createFolder} />
					<Btn label="Rename selected" muted onPress={rename} />
					<Btn label="Delete selected" muted onPress={deleteFolder} />
				</View>

				<Text style={s.title}>Import</Text>
				<Text style={s.hint}>
					Images go into the selected folder. A zip or folder becomes its own folder (named above, or after the zip/folder), and any sub-folders inside it become separate folders.
				</Text>
				<View style={s.wrap}>
					<Btn label={importing ? 'Importing\u2026' : 'Add images'} onPress={() => void runImport('images')} />
					<Btn label={importing ? 'Importing\u2026' : 'Add zip(s)'} onPress={() => void runImport('zip')} />
					<Btn label={importing ? 'Importing\u2026' : 'Add folder'} onPress={() => void runImport('folder')} />
				</View>

				<Text style={s.title}>In this folder ({col.images.length})</Text>
				{col.images.length === 0 ? (
					<Text style={s.hint}>Nothing here yet. Add images, a zip or a folder.</Text>
				) : (
					<View style={s.wrap}>
						{visible.map(img => (
							<View key={img.id} style={s.card}>
								<Image source={{ uri: img.url }} style={s.thumb} resizeMode="cover" />
								<Text numberOfLines={2} style={{ fontSize: 12 }}>{img.title}</Text>
								<Btn label="Use now" onPress={() => void useNow(img)} />
								<Btn label="Remove" muted onPress={() => removeImage(img)} />
							</View>
						))}
					</View>
				)}
				{col.images.length > shown && <Btn label={`Show more (${col.images.length - shown} left)`} muted onPress={() => setShown(shown + PAGE)} />}

				<Pressable onPress={() => commit({ size: DEFAULT_SETTINGS.size, quality: DEFAULT_SETTINGS.quality })}>
					<Text style={{ color: '#5865f2' }}>Reset image size and quality ({data.size}px, {data.quality}%)</Text>
				</Pressable>
			</View>
		</ScrollView>
	)
}
