# AutoPFP Rotator (Valenced)

Rotates your Discord profile picture through named folders of images.

- **Folders:** create, rename and delete named folders (e.g. Chrollo, Killua, Gojo). Rotation uses only the selected folder.
- **Import:** add loose images, one or more `.zip` files, or a whole folder from your phone. Everything is copied into the plugin's private storage, so it survives restarts.
- **Zips / folders:** a zip or folder becomes its own folder (named in the name box, otherwise after the zip/folder). Sub-folders inside it become separate folders automatically.
- **Order:** each folder is set to *In sequence* (line by line, looping) or *Random* (never the same image twice in a row).
- **Interval:** minimum 1 minute (Discord may enforce its own avatar cooldown, and the plugin respects it).
- Images are cropped or fitted to a square and compressed on the phone before being sent through Discord's request module.

Rotation only runs while Discord is open.
