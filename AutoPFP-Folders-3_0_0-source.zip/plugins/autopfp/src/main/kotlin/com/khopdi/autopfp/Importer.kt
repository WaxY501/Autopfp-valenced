package com.khopdi.autopfp

import android.app.Activity
import android.app.Application
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.lang.ref.WeakReference
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * Picks images, zips or a whole folder with Android's system picker and copies them into private storage.
 *
 * The picker is reached through reflection (androidx ActivityResult API), so nothing here depends on
 * classes that may not exist at build time; if Discord's screen cannot be reached the user gets a readable error.
 */
internal object Importer {
    private const val MAX_IMAGE_BYTES = 20L * 1024 * 1024
    private const val MAX_BATCH_BYTES = 1024L * 1024 * 1024
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    private fun err(message: String): String =
        JSONObject().put("ok", false).put("error", message).toString()

    // ---------------------------------------------------------------- finding Discord's screen

    @Volatile private var tracked: WeakReference<Activity>? = null
    @Volatile private var trackerInstalled = false

    private fun installTracker() {
        if (trackerInstalled) return
        try {
            val thread = Class.forName("android.app.ActivityThread")
            val app = thread.getMethod("currentApplication").invoke(null) as? Application ?: return
            app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
                override fun onActivityStarted(activity: Activity) {}
                override fun onActivityResumed(activity: Activity) { tracked = WeakReference(activity) }
                override fun onActivityPaused(activity: Activity) {}
                override fun onActivityStopped(activity: Activity) {}
                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
                override fun onActivityDestroyed(activity: Activity) {}
            })
            trackerInstalled = true
        } catch (_: Throwable) {
        }
    }

    /** The activity that is currently on screen (not paused), or null. */
    private fun findActivity(): Activity? {
        installTracker()
        tracked?.get()?.let { if (!it.isFinishing) return it }
        try {
            val threadClass = Class.forName("android.app.ActivityThread")
            val thread = threadClass.getMethod("currentActivityThread").invoke(null)
            val field = threadClass.getDeclaredField("mActivities")
            field.isAccessible = true
            val records = (field.get(thread) as? Map<*, *>)?.values ?: return null
            for (record in records) {
                if (record == null) continue
                val recordClass = record.javaClass
                val paused = recordClass.getDeclaredField("paused").apply { isAccessible = true }.getBoolean(record)
                if (paused) continue
                val activity = recordClass.getDeclaredField("activity").apply { isAccessible = true }.get(record) as? Activity
                if (activity != null) return activity
            }
        } catch (_: Throwable) {
        }
        return null
    }

    // ---------------------------------------------------------------- the picker

    suspend fun pick(kind: String, max: Int): String {
        val activity = findActivity()
            ?: return err("Could not reach Discord's screen. Close and reopen this settings page, then try again.")
        val result = CompletableDeferred<Any?>()
        activity.runOnUiThread {
            try {
                launchPicker(activity, kind, result)
            } catch (t: Throwable) {
                result.completeExceptionally(t)
            }
        }
        val picked: Any? = try {
            result.await()
        } catch (t: Throwable) {
            return err("Could not open the picker: ${t.javaClass.simpleName}: ${t.message}")
        }
        return withContext(Dispatchers.IO) {
            try {
                Session(activity, max.coerceIn(1, 2000)).run(kind, picked)
            } catch (t: Throwable) {
                err("Import failed: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun launchPicker(activity: Activity, kind: String, result: CompletableDeferred<Any?>) {
        val loader = activity.classLoader
        val registry = activity.javaClass.getMethod("getActivityResultRegistry").invoke(activity)
            ?: error("this Discord screen has no activity result registry")
        val contractName = if (kind == "folder") "OpenDocumentTree" else "OpenMultipleDocuments"
        val contractClass = Class.forName("androidx.activity.result.contract.ActivityResultContract", true, loader)
        val callbackClass = Class.forName("androidx.activity.result.ActivityResultCallback", true, loader)
        val contract = Class.forName("androidx.activity.result.contract.ActivityResultContracts\$$contractName", true, loader)
            .getDeclaredConstructor().newInstance()

        val launcherHolder = arrayOfNulls<Any>(1)
        val handler = InvocationHandler { proxy, method, callArgs ->
            when (method.name) {
                "onActivityResult" -> {
                    try {
                        val launcher = launcherHolder[0]
                        if (launcher != null) launcher.javaClass.getMethod("unregister").invoke(launcher)
                    } catch (_: Throwable) {
                    }
                    result.complete(callArgs?.get(0))
                    null
                }
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === callArgs?.get(0)
                else -> null
            }
        }
        val callback = Proxy.newProxyInstance(loader, arrayOf(callbackClass), handler)

        val register = registry.javaClass.methods.first {
            it.name == "register" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0] == String::class.java && it.parameterTypes[1] == contractClass
        }
        val key = "autopfp-${UUID.randomUUID()}"
        val launcher = register.invoke(registry, key, contract, callback) ?: error("picker did not initialize")
        launcherHolder[0] = launcher

        val input: Any? = when (kind) {
            "folder" -> null
            "zip" -> arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*")
            else -> arrayOf("image/*")
        }
        val launch = launcher.javaClass.methods.first { it.name == "launch" && it.parameterTypes.size == 1 }
        launch.invoke(launcher, *arrayOf<Any?>(input))
    }

    // ---------------------------------------------------------------- copying files in

    private class Session(private val activity: Activity, private val maxFiles: Int) {
        private val resolver = activity.contentResolver
        private val dir = File(activity.filesDir, "autopfp").apply { mkdirs() }
        private val out = JSONArray()
        private var batchBytes = 0L
        private var skipped = 0

        fun run(kind: String, picked: Any?): String {
            when (kind) {
                "folder" -> {
                    val tree = picked as? Uri
                    if (tree != null) importTree(tree)
                }
                "zip" -> for (uri in uriList(picked)) {
                    if (out.length() >= maxFiles) break
                    importZip(uri)
                }
                else -> for (uri in uriList(picked)) {
                    if (out.length() >= maxFiles) break
                    importLoose(uri)
                }
            }
            return JSONObject().put("ok", true).put("entries", out)
                .put("imported", out.length()).put("skipped", skipped).toString()
        }

        private fun uriList(picked: Any?): List<Uri> =
            (picked as? List<*>)?.filterIsInstance<Uri>() ?: emptyList()

        private fun displayName(uri: Uri): String? = try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Throwable) {
            null
        }

        private fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

        /** Copies the stream into a new private file; returns null (and cleans up) if it is not a readable image. */
        private fun store(input: InputStream, ext: String): File? {
            val dest = File(dir, "${UUID.randomUUID()}.$ext")
            try {
                var size = 0L
                dest.outputStream().use { sink ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        size += n
                        if (size > MAX_IMAGE_BYTES) error("image over 20 MB")
                        if (batchBytes + size > MAX_BATCH_BYTES) error("batch over 1 GB")
                        sink.write(buffer, 0, n)
                    }
                }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(dest.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                    dest.delete()
                    return null
                }
                batchBytes += size
                return dest
            } catch (_: Throwable) {
                dest.delete()
                return null
            }
        }

        private fun add(file: File, fileName: String, folder: String, group: String) {
            out.put(
                JSONObject()
                    .put("id", UUID.randomUUID().toString())
                    .put("url", Uri.fromFile(file).toString())
                    .put("title", fileName.substringBeforeLast('.'))
                    .put("folder", folder)
                    .put("group", group)
            )
        }

        private fun importLoose(uri: Uri) {
            val name = displayName(uri) ?: "image"
            val mime = resolver.getType(uri).orEmpty().lowercase()
            val ext = when {
                mime == "image/jpeg" || mime == "image/jpg" -> "jpg"
                mime == "image/png" -> "png"
                mime == "image/webp" -> "webp"
                mime == "image/gif" -> "gif"
                mime == "image/bmp" -> "bmp"
                extOf(name) in IMAGE_EXT -> extOf(name)
                else -> { skipped++; return }
            }
            val file = resolver.openInputStream(uri)?.use { store(it, ext) }
            if (file == null) skipped++ else add(file, name, "", "")
        }

        private fun segments(path: String): List<String> =
            path.replace('\\', '/').split('/').filter { it.isNotBlank() }

        private fun hidden(segs: List<String>): Boolean =
            segs.any { it.startsWith(".") || it == "__MACOSX" }

        private fun importZip(uri: Uri) {
            val zipName = (displayName(uri) ?: "Imported").substringBeforeLast('.').ifBlank { "Imported" }

            // Pass 1: names only, to find out whether everything sits inside one wrapper folder.
            val imagePaths = ArrayList<List<String>>()
            resolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val segs = segments(entry.name)
                            if (segs.isNotEmpty() && !hidden(segs) && extOf(segs.last()) in IMAGE_EXT) imagePaths.add(segs)
                        }
                        entry = zip.nextEntry
                    }
                }
            }
            val wrapper: String? =
                if (imagePaths.isNotEmpty() && imagePaths.all { it.size >= 2 } && imagePaths.map { it[0] }.distinct().size == 1) imagePaths[0][0] else null
            val group = wrapper ?: zipName

            // Pass 2: copy the images.
            resolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (out.length() >= maxFiles) break
                        if (!entry.isDirectory) {
                            var segs = segments(entry.name)
                            if (segs.isNotEmpty() && !hidden(segs) && extOf(segs.last()) in IMAGE_EXT) {
                                if (wrapper != null) segs = segs.drop(1)
                                val folder = if (segs.size >= 2) segs[0] else ""
                                val file = store(zip, extOf(segs.last()))
                                if (file == null) skipped++ else add(file, segs.last(), folder, group)
                            }
                        }
                        entry = zip.nextEntry
                    }
                }
            }
        }

        private fun importTree(tree: Uri) {
            val rootId = DocumentsContract.getTreeDocumentId(tree)
            val rootName = displayName(DocumentsContract.buildDocumentUriUsingTree(tree, rootId)) ?: "Imported"
            walk(tree, rootId, emptyList(), rootName)
        }

        private fun walk(tree: Uri, docId: String, path: List<String>, group: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
            )
            val found = ArrayList<Triple<String, String, String>>()
            resolver.query(children, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) found.add(Triple(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
            }
            for ((id, name, mime) in found) {
                if (out.length() >= maxFiles) return
                if (name.startsWith(".")) continue
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(tree, id, path + name, group)
                } else if (mime.startsWith("image/") || extOf(name) in IMAGE_EXT) {
                    val ext = if (extOf(name) in IMAGE_EXT) extOf(name) else mime.substringAfter('/').substringBefore('+').ifBlank { "img" }
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    val file = resolver.openInputStream(docUri)?.use { store(it, ext) }
                    if (file == null) skipped++ else add(file, name, path.firstOrNull() ?: "", group)
                }
            }
        }
    }

    // ---------------------------------------------------------------- deleting

    /** Deletes files this plugin imported. Anything outside the plugin's private folder is ignored. */
    fun deleteFiles(json: String): String {
        var removed = 0
        try {
            val list = JSONArray(json)
            for (i in 0 until list.length()) {
                val path = Uri.parse(list.getString(i)).path ?: continue
                val file = File(path)
                if (file.parentFile?.name == "autopfp" && file.isFile && file.delete()) removed++
            }
        } catch (_: Throwable) {
        }
        return JSONObject().put("ok", true).put("removed", removed).toString()
    }
}
