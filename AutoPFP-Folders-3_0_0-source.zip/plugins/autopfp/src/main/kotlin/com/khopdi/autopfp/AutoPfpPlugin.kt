@file:JvmName("AutoPfpPlugin")

package com.khopdi.autopfp

import app.valenced.plugins.PluginBuilder
import app.valenced.plugins.plugin
import app.valenced.xposed.api.registerNativeAsyncMethod
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Suppress("UNUSED")
val autoPfpPlugin: PluginBuilder = plugin {
    start {
        // args: [imageUrlOrFileUri, size, "cover" | "contain", jpegQuality]
        registerNativeAsyncMethod("${manifest.id}.process") { args ->
            val url = args[0] as String
            val size = (args[1] as Number).toInt()
            val fit = args[2] as String
            val quality = (args[3] as Number).toInt()
            withContext(Dispatchers.Default) { ImageProcessor.process(url, size, fit, quality) }
        }

        // args: ["images" | "zip" | "folder", maxFiles]
        // Opens Android's picker and copies everything into plugin-private storage.
        registerNativeAsyncMethod("${manifest.id}.pick") { args ->
            val kind = args[0] as String
            val max = (args[1] as Number).toInt()
            Importer.pick(kind, max)
        }

        // args: [json array of file:// urls]
        registerNativeAsyncMethod("${manifest.id}.deleteFiles") { args ->
            val json = args[0] as String
            withContext(Dispatchers.IO) { Importer.deleteFiles(json) }
        }

        registerNativeAsyncMethod("${manifest.id}.ping") { _ -> "ready (zip/folder import)" }
    }
}
